%%
%reseni resenych prikladu okruh 2
%autori: Vlastimil Reichel + Tatiana Keseliova 

clear all
close all
clc

cviceni=6; %zvol cviceni

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%DALE NEUPRAVOVAT%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Cviceni 2.1

if cviceni==1
    %a)
    %X_1 ~ N(20,25^2) 
    %X_2 ~ N(10,25^2)
    X_1 = 20 + 25*randn(1000,1);
    X_2 = 10 + 25*randn(1000,1);

    %b)
    %X_3 ~ N(10,25^2) 
    %X_4 ~ N(10,15^2)
    X_3 = 10 + 25*randn(1000,1);
    X_4 = 10 + 15*randn(1000,1);

    %c)
    figure
    subplot(2,2,1)
    histogram(X_1,'BinLimits',[-60,100])
    title('X\_1 ~ N(20,25^2)')
    subplot(2,2,3)
    histogram(X_2,'BinLimits',[-60,100])
    title('X\_2 ~ N(10,25^2)')
    subplot(2,2,2)
    histogram(X_3,'BinLimits',[-60,100])
    title('X\_3 ~ N(10,25^2)')
    subplot(2,2,4)
    histogram(X_4,'BinLimits',[-60,100])
    title('X\_4 ~ N(10,15^2)')
end

%% Cviceni 2.2

if cviceni==2
   %a)
    A = randn(20,1);
    B = randn(200,1);
    C = randn(2000,1);
    %b) grafick� testovanie normality
    figure
    subplot(3,1,1)
    qqplot(A)
    title('Vzorka A')
    subplot(3,1,2)
    qqplot(B)
    title('Vzorka B')
    subplot(3,1,3)
    qqplot(C)
    title('Vzorka C')

    figure
    subplot(3,1,1)
    normplot(A)
    title('Vzorka A')
    subplot(3,1,2)
    normplot(B)
    title('Vzorka B')
    subplot(3,1,3)
    normplot(C)
    title('Vzorka C')

    figure
    subplot(3,1,1)
    histogram(A)
    title('Vzorka A')
    subplot(3,1,2)
    histogram(B)
    title('Vzorka B')
    subplot(3,1,3)
    histogram(C)
    title('Vzorka C')
    %c) testovanie normality v�po�tom
    [Ha,Pa] = jbtest(A);
    [Hb,Pb] = jbtest(B);
    [Hc,Pc] = jbtest(C);

    S_a = skewness(A);
    K_a = kurtosis(A);
    S_b = skewness(B);
    K_b = kurtosis(B);
    S_c = skewness(C);
    K_c = kurtosis(C);

    fprintf('V�sledky testov normality\n')
    fprintf('Vzorka   �ikmos�   �picatos�   p-hodnota JB test\n')
    fprintf('  A       %1.3f     %1.3f       %1.3f\n',S_a,K_a,Pa)
    fprintf('  B       %1.3f     %1.3f       %1.3f\n',S_b,K_b,Pb)
    fprintf('  C       %1.3f     %1.3f       %1.3f\n',S_c,K_c,Pc)
end

%% Cviceni 2.3

if cviceni==3
    n=100; 
    alfa=0.1;
    vaha_zavazadla=20.3+2.7*randn(n,1);
    %A
    nadmerna_zavazadla=sum(vaha_zavazadla>20)
    %B
    mu=20;
    [H,P,CI]=ttest(vaha_zavazadla,mu, 'alpha', alfa);
    if H==1
        fprintf('Zam�t�me nulovou hypot�zu. \n')
    else
        fprintf('Nezam�t�me nulovou hypot�zu. \n')
    end
    fprintf('Na z�klad� vygenerovan�ho vzorku, se bude st�edn� hodnota v�hy \nzavazadla pohybovat v rozmez� %2.4f - %2.4f. \n',CI(1,1),CI(2,1));
end

%% Cviceni 2.4

if cviceni==4
    load('dlzka.mat')
    %A
    mu=75;
    [~,p,ci,stats]=ttest(dlzka,mu,'tail','right');
    fprintf('\nP-hodnota testu: %1.4f\n',p)
    %B
    fprintf('\nHodnota testovej statistiky: %2.3f\n',stats.tstat)
    fprintf('Stupne volnosti: %2.0f\n',stats.df)
    fprintf('Smerodatna odchylka: %2.3f\n',stats.sd)
    %C
    fprintf('\nKonfidencny interval: %2.3f - %2.3f\n',ci(1),ci(2))
end

%% Cviceni 2.5

if cviceni==5
    load('pravdepopodobnost_splaceni.mat')

    figure
    histogram(pred)
    hold on
    histogram(po)
    title("Pravdepodobnosti splatenia")
    legend("Pred zavedenim","Po zavedeni")
    [H,P,CI,STATS]=ttest(pred,po);

    if H==1
        fprintf('Zam�t�me nulovou hypot�zu. \n')
    else
        fprintf('Nezam�t�me nulovou hypot�zu. \n')
    end

    fprintf('Na z�klad� vzorku, se rozd�l v pravd�podobnosti �erp�n� �v�r� \np�i nov�ch pravidlech v rozmez�     od %2.4f do %2.4f. \n',CI(1,1),CI(2,1));    
end

%% Cviceni 2.6

if cviceni==6
load('slovicka.mat');
%A
figure
histogram(Metoda_A)
hold on
histogram(Metoda_B)
title('Metody uceni')
legend("Metoda A","Metoda B")
[h,p,ci,stats] = vartest2(Metoda_A,Metoda_B);
if h==1
    fprintf('Zam�t�me nulovou hypot�zu o shodnosti rozptyl� v�b�r�. \n')
else
    fprintf('Nezam�t�me nulovou hypot�zu o shodnosti rozptyl� v�b�r�. \n')
end
%B
[h,p,ci,stats] = ttest2(Metoda_A,Metoda_B);
if h==1
    fprintf('Zam�t�me nulovou hypot�zu o rovnosti st�edn�ch hodnot v�b�r�. \n')
else
    fprintf('Nezam�t�me nulovou hypot�zu  o rovnosti st�edn�ch hodnot v�b�r�. \n')
end
%C
[h,p,ci,stats] = ttest2(Metoda_A,Metoda_B,'Tail','left')
if h==1
    fprintf('Zam�t�me nulovou hypot�zu, �e by metodau�en� B byla efektivn�j�� ne� metoda A.\n')
else
    fprintf('Na 5% hladin� v�znamnosti nem��emezam�tnut nulovou hypot�zu, �e by metoda u�en� Bbyla efektivn�j�� ne� metoda A.\n')
end
end


%% Cviceni 2.7

if cviceni==7
load('design.mat')
% A - testov�n� p�edpokladu shody rozptyl�
%Shoda rozptyl�
[P,STATS]=vartestn(Plechovky)
%The low p-value, p = 0, indicates that vartestn rejects the null 
%hypothesis that the variances are equal across all five columns, in favor 
%of the alternative hypothesis that at least one column has a different 
%variance.
% B,C - anal�za rozptylu
[p,tbl,stats] = anova1(Plechovky);
end

%% Cviceni 2.8

if cviceni==8
load('mlecne.mat')

hodnoceni = mlecne(:,1);
firma = mlecne(:,2);

[P,STATS]=vartestn(hodnoceni,firma)
anova1(hodnoceni,firma)
end

%% Cviceni 2.9

if cviceni==9
%A
n=2000;
teplota_vzduchu=round(26+3*randn(n,1),1);
teplota_vody=round(teplota_vzduchu-10+3*randn(n,1),1);
pocet_prodeju=round(teplota_vzduchu*10+20*randn(n,1));
X1=[pocet_prodeju(1:20,:),teplota_vzduchu(1:20,:), ...
teplota_vody(1:20,:)];
X2=[pocet_prodeju(1:200,:),teplota_vzduchu(1:200,:), ...
teplota_vody(1:200,:)];
X3=[pocet_prodeju,teplota_vzduchu,teplota_vody];
%B
[rho1,pval1]=corr(X1)
[rho2,pval2]=corr(X2)
[rho3,pval3]=corr(X3)
end
