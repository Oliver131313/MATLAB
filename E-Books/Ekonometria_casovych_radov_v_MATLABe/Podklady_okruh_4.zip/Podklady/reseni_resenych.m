clear % promazani Workspace
close all % zavreni vsech otevrenych oken Matlabu
clc % promazani Command Window
    
    
%% uloha1
% nastaveni generatoru nahodnych cisel
rng(123456)
%nastaven� parametr�
T = 150; a0 = 0.1; a1 = 0.8; a2 = -0.2; b1 = 0.5;
% inicializace vektoru
Y = zeros(T,3); % tvorba matice nul o velikosti Tx3
eps = randn(T,1); % generovani vektoru cisel z normalniho rozdeleni o velikosti Tx1
eps2 = randn(T,1); % generovani vektoru cisel pro stochasticky trend
% simulace ARMA(2,1) procesu
for t = 3:T
Y(t,1) = a0 + a1*Y(t-1,1) + a2*Y(t-2,1) + eps(t) + b1*eps(t-1);
Y(t,2) = a0 + a1*Y(t-1,2) + a2*Y(t-2,2) + eps(t) + b1*eps(t-1)+t*a0;
Y(t,3) = a0 + a1*Y(t-1,3) + a2*Y(t-2,3) + eps(t) + b1*eps(t-1)+sum(eps2(1:t));
end
YY = Y(51:T,:); % ulozeni vybrane casti vektoru Y do noveho vektoru YY
%% Vykresleni si casove rady a jejiho korelogramu
figure_1 = figure;
subplot(3,1,1)
plot(YY(:,1)) % vykresleni casove rady
title('ARMA(2,1) model')
subplot(3,1,2)
plot(YY(:,2)) % vykresleni casove rady
title('ARMA(2,1) model + deterministick� trend (DT)')
subplot(3,1,3)
plot(YY(:,3)) % vykresleni casove rady
title('ARMA(2,1) model + stochastick� trend (ST)')
%% Vykresleni korelogramu casovych rad
figure_2 = figure;
for i=1:3
subplot(3,2,(2*i-1))
autocorr(YY(:,i)) % ACF
subplot(3,2,2*i)
parcorr(YY(:,i)) % PACF 
end
%% c)
data=YY(:,1);
save('generovana_data.mat','data')

%% uloha 2
load('generovana_data.mat')
%identifikace ARMA procesu
Model_AR10 = arima(1,0,0); % vytvoreni ARMA(1,0) modelu
Model_AR21 = arima(2,0,1); % vytvoreni ARMA(2,1) modelu
Model_AR01 = arima(0,0,1); % vytvoreni ARMA(0,1) modelu

[ARMA10_est,EPC10,logL10,info10] = estimate(Model_AR10,data); % odhad AR(1) modelu na datech
[ARMA21_est,EPC21,logL21,info21] = estimate(Model_AR21,data); % odhad ARMA(2,1) modelu
[ARMA01_est,EPC01,logL01,info01] = estimate(Model_AR01,data); % odhad MA(1) modelu na datech

ARMA_resid(:,1) = infer(ARMA10_est,data); % ziskani rezidui
ARMA_resid(:,2) = infer(ARMA21_est,data); % ziskani rezidui
ARMA_resid(:,3) = infer(ARMA01_est,data); % ziskani rezidui
% Vykresleni korelogramu rezidui
figure_3 = figure;
for i=1:3
subplot(3,2,(2*i-1))
autocorr(ARMA_resid(:,i)) % ACF
subplot(3,2,2*i)
parcorr(ARMA_resid(:,i)) % PACF 
end
%% formalni vypis ACF
for i=1:3
[acf(:,i),lags,bounds]=autocorr(ARMA_resid(:,i))
end
ARMA10=acf(:,1)
ARMA21=acf(:,2)
ARMA01=acf(:,3)
ACF_funkce=table(lags,ARMA10,ARMA21,ARMA01)

%% Vypocet informacnich kriterii
ic=zeros(3,2);
[ic(1,1),ic(1,2)] = aicbic(logL10,Model_AR10.Q+Model_AR10.P,length(data));
[ic(2,1),ic(2,2)] = aicbic(logL21,Model_AR21.Q+Model_AR21.P,length(data));
[ic(3,1),ic(3,2)] = aicbic(logL01,Model_AR01.Q+Model_AR01.P,length(data));
BIC=ic(:,2);
AIC=ic(:,1);
model={'ARMA10','ARMA21','ARMA01'}';
table(model,AIC,BIC)

%% uloha 3 - predikce

% predvytvoreni vektoru pro predikovane hodnoty
N=length(data); %delka casove rady
L=48; %zakladni sirka rozsirujiciho se okna
H=N-L; %po�et rozsireni zakladniho okna o 1 obdobi
f11 = zeros(H,1);
f21 = zeros(H,1);
f31 = zeros(H,1);

    % rucne vytvoreny ukazatel prubehu cyklu
    fprintf('\nPrubeh odhadu\n')
    fprintf('0%%     50%%      100%%\n')
    fprintf('|')
    % pomocna promenna pro graficke znazorneni prubehu
    pom_step = 0.05; %0.05 = posun po 5% 
    pom_graph = pom_step;


for T = 1:H
        [f_Model_AR10,~] = estimate(Model_AR10,data(3:L-1+T),'Y0',data(2),'Display','off');
        [f11(T),~] = forecast(f_Model_AR10,1,'Y0',data(3:L-1+T));
        [f_Model_AR21,~] = estimate(Model_AR21,data(3:L-1+T),'Y0',data(1:2),'Display','off');
        [f21(T),~] = forecast(f_Model_AR21,1,'Y0',data(3:L-1+T));
        [f_Model_AR01,~] = estimate(Model_AR01,data(3:L-1+T),'Y0',data(2),'Display','off');
        [f31(T),~] = forecast(f_Model_AR01,1,'Y0',data(3:L-1+T));

        % graficke zobrazeni prubehu po 5 %
        if T/H >= pom_graph    
            fprintf('|')
            pom_graph = pom_graph + pom_step;
        end
end

%% vykresleni
figure3 = figure;
plot(1:N,data,'color','k','LineWidth',1.15)
hold on
plot(L+1:N,f11,'color','b','LineWidth',1.15)
plot(L+1:N,f21,'color','r','LineWidth',1.15)
plot(L+1:N,f31,'color','c','LineWidth',1.15)
fN1 = zeros(N,1); %vytvoreni vektoru pro naivni predikce
fN1(2:end) = data(1:end-1); %naivni predikce y_pred=y(-1)
plot(L+1:N,fN1(L+1:N),'color','m','LineWidth',1.15)
grid on
legend('Puvodni data','ARMA(1,0) predikce','ARMA(2,1) predikce',...
    'ARMA(0,1) predikce','Naivn� predikce') % prikaz, ktery prida legendu do grafu
title('Predikce a skutecne hodnoty')

%% chyby predikce a kvalita predpovedi
e11 = f11 - data(L+1:end);
e21 = f21 - data(L+1:end);
e31 = f31 - data(L+1:end);
eN1 = fN1(L+1:N) - data(L+1:end);

% vytvoreni MSPE a RMSPE
MSPE11 = mean(e11.^2);
MSPE21 = mean(e21.^2);
MSPE31 = mean(e31.^2);
MSPEN1 = mean(eN1.^2);
MSPE=round([MSPE11;MSPE21;MSPE31;MSPEN1],4);

RMSPE11 = sqrt(mean(e11.^2));
RMSPE21 = sqrt(mean(e21.^2));
RMSPE31 = sqrt(mean(e31.^2));
RMSPEN1 = sqrt(mean(eN1.^2));
RMSPE=round([RMSPE11;RMSPE21;RMSPE31;RMSPEN1],4);

model_predikce={'ARMA10','ARMA21','ARMA01','NAIVNI'}';
table(model_predikce,MSPE,RMSPE)

%% uloha 4 - testy jednotkoveho ko�ene

%printf('ADF test?H0: rada ma jednotkovy koren, H1: rada je stacionarni/trendovestacionarni')
for i=1:3
[h,pValue,stat,cValue,reg] =adftest(YY(:,i),'lags',12);
ADF_NotUnitRoot(i,1)=h;
ADF_pValue(i,1)=pValue;

[h,pValue,stat,cValue,reg] =kpsstest(YY(:,i),'lags',1)%,'trend',false);
KPSS_UnitRoot(i,1)=h;
KPSS_pValue(i,1)=pValue;
end
Proces={'ARMA(2,1)';'ARMA(2,1)+ DT';'ARMA(2,1)+ ST'};
table(Proces,ADF_NotUnitRoot,ADF_pValue,KPSS_UnitRoot,KPSS_pValue)


%% uloha 5 - detrendovani

%A)
y=YY(:,2);

t = (1:100)'; % vektor indexujici cas
T = length(YY); % pocet pozorovani
X = ones(T,1); % matice regresoru, nyni pouze konstanta
    for p = 1:2
        X(:,1+p) = t.^p; % time = logicky cas, umocneny podle cyklu, ve kterem se nachazime (radu polynomu)
                         % postupne rozsirujeme seznam regresoru - navysujeme rad polynomu
        model = fitlm(X,y); % odhad trendu pomoci regrese
        yc_pol(:,p) = model.Residuals.Raw; % reziduum jako cyklicka slozka produktu = mezera vystupu
        yp_pol(:,p) = model.Fitted; % trend = vyrovnane hodnoty jako potencialni produkt
    end

% Vykresleni puvodni rady a detrendovanych rad
figure_2 = figure;
subplot(2,1,1)
plot(y,'g')
hold on
plot(yp_pol(:,1),'r')
plot(yp_pol(:,2),'b')
legend('y','pol 1','pol 2')
title('Puvodni rada a trendove slozky')
subplot(2,1,2)
plot(yc_pol(:,1),'r')
hold on
plot(yc_pol(:,2),'b')
plot(1:1:100,zeros(100,1),'k')
legend('pol 1','pol 2')
title('Cyklicke slozky')   

%B)
y2=YY(:,3);
y2_diff=diff(y2);
figure
subplot(2,1,1)
plot(y2)
subplot(2,1,2)
plot(y2_diff)

%C)
figure
plot(YY(2:end,1),'k','LineWidth',2)
hold on
plot(yc_pol(2:end,1),'r')
plot(yc_pol(2:end,2),'b')
plot(y2_diff)
legend('Skutecna cyklicka slozka (rada YY1)','Cyklicka slozka po detrendovani primkou (rada YY2)',...
    'Cyklicka slozka po detrendovani parabolou (rada YY2)','Cyklicka slozka po diferencovani  (rada YY3)')

