%Generator prikladov pre druhu DU zo Zakladov MATLABu
 clc
 clear
 close all

%% Nacitanie vstupov
%nacitanie dat o zapisanych studentoch ZMAT 
%do jednotlivych premennych NUM, TXT, RAW sa nacitaju matice (roznych 
%typov) obsahujuce postupne a) len ciselne hodnoty, b) len textove retazce,
%c) cely obsah listu
 [NUM,TXT,RAW] = xlsread('seznam_ZMAT_2021.xlsx');
%extrahovanie UCO a mena studenta
 UCO = NUM; %NUM je matica dat ciselnych hodnot
            %(je obsahom len druheho stlpca Excelovskeho suboru)
 meno = string(TXT(2:end,3)); %prevedie druhy stlpec datoveho
                               %typu cell array na string array
                               %maticu obsahujucu textove retazce

%% Generovanie uloh
%nastavenie "seedu" generatoru nahodnych cisel na konkretnu hodnotu 
% (generovanie bude davat rovnake vysledky aj pri opakovanom spustani)
 rng(141021)
%riadkovy vektor cisiel najzaujimavejsich uloh z kapitoly 2
 quest_best_4 = [1:3,6:8,10:12,14,15,17:19,21,23,25,26,28:31];
%riadkovy vektor cisiel najzaujimavejsich uloh z kapitoly 3

%  quest_best_5 = [1,2,5:8,10,14,15,16,18,21,22,23,29:33,37:39]; 

%nahodne vygenerovany vektor cisiel otazok
%vyuziva velmi uzitocnu funkciu Statistics toolboxu "datasample"
 quest_4 = datasample(quest_best_4,length(UCO),'Replace',true);
%  quest_5 = datasample(quest_best_5,length(UCO),'Replace',true);
 
%% Textovy vystup na obrazovku a do suboru
%vystup do textoveho suboru s pouzitim fprintf s vystupom do textoveho 
% suboru 
%nazov suboru
 dfile ='uloha_02.txt';
%identifikator suboru a jeho otvorenie pre zapis vratane zmazania
%pripadneho existujuceho obsahu
 FID = fopen(dfile,'w+');
%zapisanie jednotlivych riadkov textoveho suboru 
fprintf(FID,'%10s %25s %15s %15s \n ','U�O','Meno','Kapitola 4');
fprintf(FID,'=======================================================\n');
for ii=1:length(UCO)
   fprintf(FID,'%10d %25s %15d \n',UCO(ii),meno(ii),quest_4(ii));
end
%vytvorenie premennej (objektu) typu table
 quest_table = table(int32(UCO),meno,quest_4');
 quest_table.Properties.VariableNames = {'UCO','Meno','Kapitola_4'};
 %quest_table.Properties.VariableTypes = {'uint16','string','int8','int8'};
 quest_table.Properties.Description = 'Zadanie ot�zok D� 2';
 disp(quest_table)
%Uzavretie suboru
fclose(FID);


