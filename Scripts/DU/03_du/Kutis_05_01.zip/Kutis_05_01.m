%% Kapitola 5 - Priklad 1
% Write a for loop that will print the column of real numbers from 1.5 to 2.7 in
% steps of 0.2.

for i = 1.5:0.2:2.7
    disp(i)
end